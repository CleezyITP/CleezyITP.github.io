var greeting="hello world"

document.write(greeting)